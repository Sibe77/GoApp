# GoApp

Uso:

Clonar el repositorio, e instalar los paquetes de NPM con $ npm install

Para correr una prueba en un dispositivo real ejecutar $ phonegap serve y acceder en el móvil desde la aplicación de phonegap

Al subir una nueva versión cambiar el numero de la misma desde el archivo config.xml